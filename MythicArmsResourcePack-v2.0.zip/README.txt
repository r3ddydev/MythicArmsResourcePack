MythicArms Resource Pack (Customer Edition)
===========================================

Version target
--------------
- Minecraft Java 1.21 / 1.21.1

What this pack changes
----------------------
- CustomModelData-based visuals for MythicArms weapons.
- Noticeable, theme-matched icons while staying vanilla-asset compatible.

Mapped weapon ids
-----------------
- inferno_blade   -> 21001 (diamond_sword)
- frost_fang      -> 21002 (diamond_sword)
- shadow_dagger   -> 22001 (golden_sword)
- wind_cutter     -> 23001 (iron_axe)
- thunder_spear   -> 24001 (iron_sword)
- life_stealer    -> 25001 (netherite_sword)
- tornado_staff   -> 26001 (blaze_rod)
- guardian_shield -> 27001 (shield)

Install on server
-----------------
1) Upload the zip file to a direct link host.
2) Set server.properties:
   - require-resource-pack=true
   - resource-pack=<direct zip url>
   - resource-pack-sha1=<sha1 of this zip>
3) Restart server.

Notes
-----
- Normal vanilla tools stay unchanged.
- Only items with matching CustomModelData values are skinned.
