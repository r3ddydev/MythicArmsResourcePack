MythicArms Starter Skins Pack
=============================

What this pack does
-------------------
- Adds starter visuals for MythicArms weapons using CustomModelData.
- No external dependencies required.
- Uses vanilla texture assets for compatibility and easy replacement later.

Install
-------
1) Zip the contents of this resourcepack folder (pack.mcmeta + assets folder).
2) Put the zip on your host/CDN.
3) Set your server resource-pack URL in server.properties.
4) Ensure players accept/download the pack.

Defaults mapped in plugin config
--------------------------------
inferno_blade   -> 21001 (diamond_sword)
frost_fang      -> 21002 (diamond_sword)
shadow_dagger   -> 22001 (golden_sword)
wind_cutter     -> 23001 (iron_axe)
thunder_spear   -> 24001 (trident)
life_stealer    -> 25001 (netherite_sword)
tornado_staff   -> 26001 (blaze_rod)
guardian_shield -> 27001 (shield)

Customize later
---------------
- Replace files under assets/mythicarms/models/item/*.json to point at your own textures.
- Add your own textures and update model "textures.layer0" paths.
- Keep the same CustomModelData values unless you update config too.
