MythicArms Starter Skins Pack
=============================

What this pack does
-------------------
- Adds starter visuals for MythicArms weapons using CustomModelData.
- No external dependencies required.
- Uses vanilla texture assets for compatibility and easy replacement later.

Install
-------
1) Zip the contents of this resourcepack folder (pack.mcmeta + assets folder).
2) Put the zip on your host/CDN.
3) Set your server resource-pack URL in server.properties.
4) Ensure players accept/download the pack.

Model tokens (Minecraft 1.21.4+ clients)
----------------------------------------
The plugin sets custom_model_data strings: mythicarms:<weapon_id>
Examples:
- inferno_blade   -> mythicarms:inferno_blade   (diamond_sword)
- frost_fang      -> mythicarms:frost_fang      (diamond_sword)
- shadow_dagger   -> mythicarms:shadow_dagger   (golden_sword)
- wind_cutter     -> mythicarms:wind_cutter     (iron_axe)
- thunder_spear   -> mythicarms:thunder_spear   (trident)
- life_stealer    -> mythicarms:life_stealer    (netherite_sword)
- tornado_staff   -> mythicarms:tornado_staff   (blaze_rod)
- guardian_shield -> mythicarms:guardian_shield (shield)

Legacy numeric CMD (optional)
-----------------------------
config skin.custom-model-data integers still apply for older clients using model overrides.

Customize later
---------------
- Replace files under assets/mythicarms/models/item/*.json to point at your own textures.
- Add your own textures and update model "textures.layer0" paths.
- Keep the same CustomModelData values unless you update config too.

Vanilla safety
--------------
- Normal tools stay vanilla: only items carrying MythicArms string tokens (mythicarms:<id>)
  or matching legacy numeric CustomModelData pick the alternate models.
- Do not reuse the same mythicarms:<id> token on other items unless you intend them to look
  like that weapon.
